# Code of conduct

By participating in this project, you agree to abide by the
[Blues Inc code of conduct][1].

[1]: https://blues.github.io/opensource/code-of-conduct

