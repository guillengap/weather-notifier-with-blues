#include <Arduino.h>
#include <Notecard.h>
#include <NotecardPseudoSensor.h>
#include "DHT20.h" //DHT20

DHT20 DHT; //DHT20

using namespace blues;

#define usbSerial Serial
#define productUID "com.blues.tvantoll.your_project" // paste here your UID project

Notecard notecard;
NotecardPseudoSensor sensor(notecard);

void setup() {
  // put your setup code here, to run once:
DHT.begin();    //DHT20  
delay(2500);
usbSerial.begin(115200);

notecard.begin();
notecard.setDebugOutputStream(usbSerial);

J *req = notecard.newRequest("hub.set");
JAddStringToObject(req, "product", productUID);
JAddStringToObject(req, "mode", "continuous");
notecard.sendRequest(req);
}

void loop() {
  // put your main code here, to run repeatedly: UPDATE
int status = DHT.read(); //DHT20
float temperature = DHT.getTemperature(); //DHT20
float humidity = DHT.getHumidity(); //DHT20

usbSerial.print("Temperature = ");
usbSerial.print(temperature);
usbSerial.println(" *C");
usbSerial.print("Humidity = ");
usbSerial.print(humidity);
usbSerial.println(" %");

switch (status)
    {
      case DHT20_OK:
        usbSerial.print("OK");
        break;
      case DHT20_ERROR_CHECKSUM:
        usbSerial.print("Checksum error");
        break;
      case DHT20_ERROR_CONNECT:
        usbSerial.print("Connect error");
        break;
      case DHT20_MISSING_BYTES:
        usbSerial.print("Missing bytes");
        break;
      case DHT20_ERROR_BYTES_ALL_ZERO:
        usbSerial.print("All bytes read zero");
        break;
      case DHT20_ERROR_READ_TIMEOUT:
        usbSerial.print("Read time out");
        break;
      case DHT20_ERROR_LASTREAD:
        usbSerial.print("Error read too fast");
        break;
      default:
        usbSerial.print("Unknown error");
        break;
    }
    usbSerial.print("\n");

  J *req = notecard.newRequest("note.add");
  if (req != NULL)
  {
    JAddStringToObject(req, "file", "sensors.qo");
    JAddBoolToObject(req, "sync", true);
    J *body = JAddObjectToObject(req, "body");
    if (body)
    {
      JAddNumberToObject(body, "temp", temperature);
      JAddNumberToObject(body, "humidity", humidity);
    }
    notecard.sendRequest(req);
  }

delay(15000);
}

